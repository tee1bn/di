
<?php
    
    
    $page_title = "How it works";
    include 'includes/header.php';?>



    <!--== About Area Start ==-->
    <section id="about-area" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>How it works.</h2>
                        <p>Hare is some informaton on our company and teme member information to yoiu know</p>
                    </div>
                </div>
            </div>
         <div class="col-lg-12">
                   how it wowrks
                </div>
        </div>

   
    </section>
    <!--== About Area End ==-->


   

   <?php include 'includes/footer.php';?>