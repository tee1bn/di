
<?php
    
    
    $page_title = "Who we are";
    include 'includes/header.php';?>



    <!--== About Area Start ==-->
    <section id="about-area" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Who we are.</h2>
                        <p>Hare is some informaton on our company and teme member information to yoiu know</p>
                    </div>
                </div>
            </div>
         <div class="col-lg-12">
                   Who we are 
                </div>
        </div>

   
    </section>
    <!--== About Area End ==-->


   

   <?php include 'includes/footer.php';?>